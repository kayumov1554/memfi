// 1 - masala
// const L = 5000
// console.log(L / 100);

// 2 - masala

// const kg = 9000

// console.log(kg / 1000);

// 3 - masala

// const kb = 10240

// console.log(kb / 1024);

// 6 - masala

// const a = 23

// const birliklar = Math.floor(a - 21)
// const onliklar = Math.floor(a - 20)

// console.log(onliklar, birliklar);

// 7 - masala

// const a = 54

// const birliklar = Math.floor(a - 50)
// const onliklar = Math.floor(a - 49)

// console.log(onliklar, birliklar);

// 8-masala

// const a = 23

// const birliklar = Math.floor(a - 21)
// const onliklar = Math.floor(a - 20)

// console.log(onliklar, birliklar);

// 9 - masala

// const a = 345

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(yuzliklar);

// 10-masala

// const a = 456

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(birliklar, onliklar);

// 11-masala

// const a = 345

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(yuzliklar, onliklar, birliklar);

// 12 - masala

// const a = 345

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(yuzliklar, onliklar, birliklar);

// 13 - masala

// const a = 345

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(yuzliklar, onliklar);

// 14 - masala

// const a = 345

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(onliklar, birliklar);

// 15 - masala

// const a = 123

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(onliklar, birliklar, yuzliklar);

// 16 - masala

// const a = 123

// const birliklar = Math.floor(a / 100)
// const onliklar = Math.floor((a % 100) / 10)
// const yuzliklar = Math.floor(a % 10)

// console.log(birliklar, yuzliklar, onliklar);

// 17 - masala

// const a = 1450

// const bolish = Math.floor(a / 2)
// const bolish1 = Math.floor(bolish / 2)
// const birliklar = Math.floor(bolish1 / 100)
// const onliklar = Math.floor((bolish1 % 100) / 10)
// const yuzliklar = Math.floor(bolish1 % 10)
// console.log(yuzliklar);

// 18 - masala

// const a = 12356

// const bolish = Math.floor(a / 2)
// const bolish1 = Math.floor(bolish / 2)
// const mingliklar = Math.floor((bolish1 % 1000) % 10)

// console.log(mingliklar);

// 19 - masala

// const sikund = 60

// const soat = Math.floor(sikund * 60)
// const kun = Math.floor(soat * 24)

// console.log(kun);

// 20 - masala

// const sikund = 60

// const minut = Math.floor(sikund * 24)
// const soat = Math.floor(minut / 60)

// console.log(soat);

// 21 - masala

// const sikund = 1
// const minut = 60

// const soat = Math.floor(minut * 1440)
// const sekund = Math.floor(soat / minut)

// console.log(soat, sekund);

// 22-masala

// const sikund = 1
// const minut = 60
// const soat = 24

// const kun = Math.floor(soat * minut)
// const kunlar = Math.floor(minut * sikund)
// const javob = Math.floor(kun * kunlar)

// console.log(kun, javob);

// 23 - masala

// const sikund = 1
// const minut = 60
// const soat = 24

// const kun = Math.floor(soat * minut)
// const kunlar = Math.floor(minut * sikund)
// const javob = Math.floor(kun * kunlar)
// const sohat = Math.floor(kun / kunlar)

// console.log(sohat, kun, javob);